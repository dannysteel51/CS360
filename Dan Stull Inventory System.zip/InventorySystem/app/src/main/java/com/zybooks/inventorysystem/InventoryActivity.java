package com.zybooks.inventorysystem;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toolbar;

public class InventoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_activity);
    }
}