package com.zybooks.inventorysystem;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.content.Intent;


public class MainActivity extends AppCompatActivity {

    EditText UName;
    EditText UPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void register(View view){
        EditText UName = (EditText) findViewById(R.id.Username);
        EditText UPassword = (EditText)  findViewById(R.id.Password);
        String CreateUserName = UName.getText().toString();
        String CreatePassword = UPassword.getText().toString();

        //DatabaseHandler db = new DatabaseHandler(MainActivity.this);

        //db.addNewUserCredentials(CreateUserName, CreatePassword);

        Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
        startActivity(intent);
    }
}